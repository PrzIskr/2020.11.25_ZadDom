#Przemysław Iskra
#nr almumu: 145863
#grupa: L6
# zadanie 5a

name_list = ['Damian', 'Ola', 'Barbara', 'Robert', 'Zygmunt', 'Ewa']

letter_list = [name[0] for name in name_list]

print(letter_list)